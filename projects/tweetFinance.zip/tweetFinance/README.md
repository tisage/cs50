# tweetFinance
tweets analysis on finance equity
